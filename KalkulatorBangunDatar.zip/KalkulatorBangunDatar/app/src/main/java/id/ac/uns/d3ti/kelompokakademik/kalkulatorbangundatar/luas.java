package id.ac.uns.d3ti.kelompokakademik.kalkulatorbangundatar;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class luas extends AppCompatActivity {
    TextView txt;
    Button b;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_luas);
        txt=(TextView)findViewById(R.id.txt_hasil);
        b=(Button)findViewById(R.id.button3);
        Intent myLocalIntent= getIntent();
// look into the bundle sent to Activity2 for data items
        Bundle myBundle= myLocalIntent.getExtras();
        Double v1 = myBundle.getDouble("luas");

// for illustration purposes. show data received & result
        txt.setText("luas =" +v1 );
        // add to the bundle the computed result

// attach updated bumble to invoking intent
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(luas.this, MainActivity.class);
                startActivity(i);
            }
        });
    }
}